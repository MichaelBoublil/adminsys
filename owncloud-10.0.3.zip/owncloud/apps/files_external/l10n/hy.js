OC.L10N.register(
    "files_external",
    {
    "Personal" : "Անձնական",
    "Saved" : "Պահված",
    "Username" : "Օգտանուն",
    "Password" : "Գաղտնաբառ",
    "Save" : "Պահպանել",
    "Port" : "Պորտ",
    "WebDAV" : "WebDAV",
    "URL" : "URL",
    "Dropbox" : "Dropbox",
    "Location" : "Տեղակայություն",
    "Host" : "Հոստ",
    "Share" : "Կիսվել",
    "Name" : "Անուն",
    "Never" : "Երբեք",
    "Folder name" : "Պանակի անուն",
    "Delete" : "Ջնջել"
},
"nplurals=2; plural=(n != 1);");
