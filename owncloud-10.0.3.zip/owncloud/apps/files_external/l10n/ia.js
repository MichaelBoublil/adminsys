OC.L10N.register(
    "files_external",
    {
    "Personal" : "Personal",
    "Saved" : "Salveguardate",
    "Username" : "Nomine de usator",
    "Password" : "Contrasigno",
    "Save" : "Salveguardar",
    "Region" : "Region",
    "URL" : "URL",
    "Location" : "Loco",
    "Share" : "Compartir",
    "Name" : "Nomine",
    "Folder name" : "Nomine de dossier",
    "Delete" : "Deler"
},
"nplurals=2; plural=(n != 1);");
