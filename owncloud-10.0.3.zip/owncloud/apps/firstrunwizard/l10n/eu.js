OC.L10N.register(
    "firstrunwizard",
    {
    "Get the apps to sync your files" : "Lortu aplikazioak zure fitxategiak sinkronizatzeko",
    "Desktop client" : "Mahaigaineko bezeroa",
    "Android app" : "Android aplikazioa",
    "iOS app" : "iOS aplikazioa",
    "Connect your desktop apps to %s" : "Konektatu zure mahaigaineko aplikazioak %s-era",
    "Connect your Calendar" : "Konektatu zure Egutegia",
    "Connect your Contacts" : "Konektatu zure Kontaktuak",
    "Documentation" : "Dokumentazioa",
    "Access files via WebDAV" : "Eskuratu fitxategiak WebDAV bidez",
    "There’s more information in the <a target=\"_blank\" href=\"%s\">documentation</a> and on our <a target=\"_blank\" href=\"http://owncloud.org\">website</a>." : "Informazio gehiago dago <a  target=\"_blank\" href=\"%s\"\">dokumentazioan</a> eta gure <a  target=\"_blank\" href=\"http://owncloud.org\">web gunean</a>."
},
"nplurals=2; plural=(n != 1);");
