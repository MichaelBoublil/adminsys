<?php
$TRANSLATIONS = array(
"Your personal web services. All your files, contacts, calendar and more, in one place." => "Sus servicios web personales. Todos sus archivos, contactos, calendario y más en un único lugar.",
"Get the apps to sync your files" => "Obtenga las apps para sincronizar sus archivos",
"Connect your Calendar" => "Conecte su Calendario",
"Connect your Contacts" => "Conecte sus Contactos",
"Access files via WebDAV" => "Acceda a sus archivos vía WebDAV",
"Documentation" => "Documentación",
"There’s more information in the <a target=\"_blank\" href=\"%s\">documentation</a> and on our <a target=\"_blank\" href=\"http://owncloud.org\">website</a>." => "Hay más información en la <a target=\"_blank\" href=\"%s\">documantación</a> y en nuestro  <a target=\"_blank\" href=\"http://owncloud.org\">sitio web</a>."
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
