OC.L10N.register(
    "firstrunwizard",
    {
    "Get the apps to sync your files" : "Obteña as aplicacións para sincronizar os seus ficheiros",
    "Desktop client" : "Cliente de escritorio",
    "Android app" : "Aplicación Android",
    "iOS app" : "Aplicación iOS",
    "Connect your desktop apps to %s" : "Conecte as súas aplicacións de escritorio con %s",
    "Connect your Calendar" : "Conecte o seu calendario",
    "Connect your Contacts" : "Conecte os seus contactos",
    "Documentation" : "Documentación",
    "Access files via WebDAV" : "Acceda aos ficheiros empregando WebDAV",
    "There’s more information in the <a target=\"_blank\" href=\"%s\">documentation</a> and on our <a target=\"_blank\" href=\"http://owncloud.org\">website</a>." : "Dispón de máis información na <a target=\"_blank\" href=\"%s\">documentación</a> e no noso <a target=\"_blank\" href=\"http://owncloud.org\">sitio web</a>."
},
"nplurals=2; plural=(n != 1);");
