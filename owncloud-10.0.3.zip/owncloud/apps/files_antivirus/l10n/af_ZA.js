OC.L10N.register(
    "files_antivirus",
    {
    "Advanced" : "Gevorderd"
},
"nplurals=2; plural=(n != 1);");
