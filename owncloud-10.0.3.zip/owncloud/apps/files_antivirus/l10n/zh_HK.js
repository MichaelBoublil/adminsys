OC.L10N.register(
    "files_antivirus",
    {
    "Greetings {user}," : "歡迎{user}",
    "Sorry, but a malware was detected in a file you tried to upload and it had to be deleted." : "對不起, 你所上傳的文件含有惡意軟體, 該文件將被刪除.",
    "File uploaded: {file}" : "文件已被上傳: {file}",
    "Antivirus Configuration" : "防毒功能設定",
    "Mode" : "橂式",
    "Executable" : "可執行",
    "Port" : "連接埠",
    "Delete file" : "刪除文件",
    "Save" : "儲存",
    "Advanced" : "進階"
},
"nplurals=1; plural=0;");
