OC.L10N.register(
    "files_antivirus",
    {
    "Save" : "Պահպանել",
    "Description" : "Նկարագրություն"
},
"nplurals=2; plural=(n != 1);");
