OC.L10N.register(
    "files_antivirus",
    {
    "Host" : "Host",
    "Save" : "Späicheren",
    "Advanced" : "Avancéiert",
    "Description" : "Beschreiwung"
},
"nplurals=2; plural=(n != 1);");
