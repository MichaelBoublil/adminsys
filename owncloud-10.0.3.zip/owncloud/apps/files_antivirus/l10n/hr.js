OC.L10N.register(
    "files_antivirus",
    {
    "Executable" : "Izvršan",
    "Host" : "Poslužitelj",
    "Port" : "Port",
    "Delete file" : "Obriši datoteku",
    "Save" : "Snimi",
    "Advanced" : "Napredno",
    "Rules" : "Pravilo",
    "Description" : "Opis",
    "Mark as" : "Označi kao",
    "Add a rule" : "Dodaj pravilo"
},
"nplurals=3; plural=n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2;");
