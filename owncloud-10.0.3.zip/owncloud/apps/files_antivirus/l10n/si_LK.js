OC.L10N.register(
    "files_antivirus",
    {
    "Mode" : "ආකාරය",
    "Host" : "සත්කාරකය",
    "Address of Antivirus Host." : "ප්‍රතිවයිරස සත්කාරකයේ ලිපිනය",
    "Port" : "තොට",
    "Action for infected files found while scanning" : "පිරික්සුමේදි හමුවන ආසාධිත ගොනු සඳහා ගතයුතු පියවර",
    "Only log" : "වාර්තා කිරීම පමණක් කරන්න",
    "Delete file" : "ගොනුය මකන්න",
    "Save" : "සුරකින්න",
    "Advanced" : "දියුණු/උසස්",
    "Description" : "විස්තරය"
},
"nplurals=2; plural=(n != 1);");
