OC.L10N.register(
    "files_antivirus",
    {
    "Save" : "భద్రపరచు",
    "Advanced" : "ఉన్నతం"
},
"nplurals=2; plural=(n != 1);");
