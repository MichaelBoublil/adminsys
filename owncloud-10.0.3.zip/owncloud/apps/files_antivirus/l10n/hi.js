OC.L10N.register(
    "files_antivirus",
    {
    "Save" : "सहेजें",
    "Advanced" : "उन्नत"
},
"nplurals=2; plural=(n != 1);");
