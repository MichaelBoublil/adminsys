OC.L10N.register(
    "files_antivirus",
    {
    "Save" : "Simpan",
    "Advanced" : "Maju",
    "Description" : "Keterangan"
},
"nplurals=1; plural=0;");
