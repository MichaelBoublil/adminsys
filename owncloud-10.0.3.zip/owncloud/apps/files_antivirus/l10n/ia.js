OC.L10N.register(
    "files_antivirus",
    {
    "Save" : "Salveguardar",
    "Advanced" : "Avantiate",
    "Description" : "Description"
},
"nplurals=2; plural=(n != 1);");
