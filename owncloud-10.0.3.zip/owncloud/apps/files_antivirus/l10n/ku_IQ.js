OC.L10N.register(
    "files_antivirus",
    {
    "Save" : "پاشکه‌وتکردن",
    "Advanced" : "هه‌ڵبژاردنی پیشكه‌وتوو",
    "Description" : "پێناسه"
},
"nplurals=2; plural=(n != 1);");
