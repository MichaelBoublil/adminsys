OC.L10N.register(
    "files_antivirus",
    {
    "Mode" : "ھالەت",
    "Host" : "باش ئاپپارات",
    "Port" : "ئېغىز",
    "Delete file" : "ھۆججەت ئۆچۈر",
    "Save" : "ساقلا",
    "Advanced" : "ئالىي",
    "Description" : "چۈشەندۈرۈش"
},
"nplurals=1; plural=0;");
