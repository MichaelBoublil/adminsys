OC.L10N.register(
    "files_antivirus",
    {
    "Save" : "حفظ",
    "Advanced" : "ایڈوانسڈ",
    "Description" : "تصریح"
},
"nplurals=2; plural=(n != 1);");
