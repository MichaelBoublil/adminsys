OC.L10N.register(
    "files_antivirus",
    {
    "Host" : "Tenar",
    "Save" : "Lagre",
    "Advanced" : "Avansert",
    "Description" : "Skildring"
},
"nplurals=2; plural=(n != 1);");
