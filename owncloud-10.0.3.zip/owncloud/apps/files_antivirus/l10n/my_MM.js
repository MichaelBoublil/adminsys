OC.L10N.register(
    "files_antivirus",
    {
    "Advanced" : "အဆင့်မြင့်",
    "Description" : "ဖော်ပြချက်"
},
"nplurals=1; plural=0;");
