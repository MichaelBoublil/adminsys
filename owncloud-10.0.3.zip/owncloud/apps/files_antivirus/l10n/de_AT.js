OC.L10N.register(
    "files_antivirus",
    {
    "Host" : "Host",
    "Port" : "Port",
    "Save" : "Speichern",
    "Advanced" : "Erweitert",
    "Description" : "Beschreibung"
},
"nplurals=2; plural=(n != 1);");
