<?php
$TRANSLATIONS = array(
"Save" => "tallentaa"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
