OC.L10N.register(
    "files_antivirus",
    {
    "Host" : "হোস্ট",
    "Save" : "সেভ",
    "Description" : "বর্ণনা"
},
"nplurals=2; plural=(n != 1);");
